import { base44 } from './base44Client';


export const PromptHistory = base44.entities.PromptHistory;



// auth sdk:
export const User = base44.auth;